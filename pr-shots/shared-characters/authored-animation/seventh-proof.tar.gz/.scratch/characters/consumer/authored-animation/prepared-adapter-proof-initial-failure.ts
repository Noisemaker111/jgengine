import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {entityModels as scrapModels,readPlayerAnimation as scrapRead} from './games/scrap-signal/src/game/world/models';
import {entityModels as lanternModels,readPlayerAnimation as lanternRead} from './games/lantern-reach/src/game/models';
import {entityModels as originalScrapModels} from './original-games/scrap-signal/src/game/world/models';
import {entityModels as originalLanternModels} from './original-games/lantern-reach/src/game/models';
import {game as scrap} from './games/scrap-signal/src/game.config';
import {game as lantern} from './games/lantern-reach/src/game.config';
import {game as originalScrap} from './original-games/scrap-signal/src/game.config';
import {game as originalLantern} from './original-games/lantern-reach/src/game.config';
import {createGameContext} from '@jgengine/core/runtime/gameContext';
import {createEmptyEditorDocument,importEditorDocumentJson,type EditorDocument} from '@jgengine/core/editor/document';
import {createDocumentLiveSync,installDocumentLiveSync} from '@jgengine/core/editor/liveSync';
import {resolveEntityModel} from '@jgengine/shell/render/resolveModel';
import {resolveAuthoredObjects,markerCatalogId,ENTITY_MARKER_KINDS} from '@jgengine/core/world/authoredObjects';
const sha=(s:string)=>createHash('sha256').update(s).digest('hex');
const manifest=JSON.parse(readFileSync(new URL('./candidate-package-manifest.json',import.meta.url),'utf8'));
const profiles=JSON.parse(readFileSync(new URL('../../authored-animation/asset-profiles.json',import.meta.url),'utf8'));
const records=[];
for(const [name,game,original,models,old,read,markerId,actorKinds] of [
 ['scrap',scrap,originalScrap,scrapModels,originalScrapModels,scrapRead,'player_spawn',['reactor_hunter']],
 ['lantern',lantern,originalLantern,lanternModels,originalLanternModels,lanternRead,'spawn:player',['player_hero','player_warrior']],
] as const){
 const file=new URL(`./games/${name==='scrap'?'scrap-signal':'lantern-reach'}/src/editor.scene.json`,import.meta.url);
 const sourceText=readFileSync(file,'utf8');const source=JSON.parse(sourceText) as EditorDocument;
 const marker=source.markers.find(m=>m.id===markerId)!;
 assert.deepEqual(Object.keys(models).sort(),Object.keys(old).sort());
 for(const key of Object.keys(models)){
  const {animation:before,...oldFields}=old[key]!;const {animation:after,...fields}=models[key]!;
  assert.deepEqual(fields,oldFields,`${name}/${key}: all model fields except animation preserved`);
  if(!(actorKinds as readonly string[]).includes(key))assert.deepEqual(after,before,`${name}/${key}: non-player/class animation preserved`);
 }
 assert.equal(read().diagnostics.length,0);assert.deepEqual(read().animation,marker.meta?.animation);
 for(let i=0;i<1000;i++)assert.equal(read(),read(),'unchanged document keeps resolved result identity');
 const assetId=markerCatalogId(marker)!;const asset=game.game.assets.resolve(assetId)!;assert.ok(asset);
 assert.equal(asset.url,name==='scrap'?models.reactor_hunter!.url:models.player_hero!.url);
 assert.deepEqual(asset.clips,profiles[name].clips,'registered preview clips match actual measured rig');
 const excluded=[...ENTITY_MARKER_KINDS,'player_spawn'];
 assert.ok(!resolveAuthoredObjects(source,{excludeKinds:excluded}).some(m=>m.instanceId===markerId));
 const doc=name==='scrap'?importEditorDocumentJson(sourceText):{...createEmptyEditorDocument(),markers:[structuredClone(marker)]};
 const live=createDocumentLiveSync(createEmptyEditorDocument());const detach=installDocumentLiveSync(live);
 const fallback=read().animation;assert.deepEqual(fallback,old[actorKinds[0]]!.animation);
 live.replaceDocument(doc);const first=read();assert.equal(first.diagnostics.length,0);
 const adjusted=structuredClone(doc);adjusted.markers.find(m=>m.id===markerId)!.meta!.animation={...(marker.meta!.animation as object),timeScale:0.8};
 live.replaceDocument(adjusted);assert.equal((read().animation as any).timeScale,0.8);
 const resolved=resolveEntityModel(models[actorKinds[0]],game.game.assets,actorKinds[0])!;assert.equal((resolved.animation as any).timeScale,0.8,'actual public model resolver reads current getter including attachments');
 const malformed=structuredClone(doc);(malformed.markers.find(m=>m.id===markerId)!.meta!.animation as any).graph.layers[0].transitions[0].to='missing-state';
 live.replaceDocument(malformed);const invalid=read();assert.equal(invalid.animation,fallback);assert.ok(invalid.diagnostics.some(d=>d.path.includes('.graph.')&&d.repair.length>0));
 const diagnostic=invalid.diagnostics;assert.equal(read(),invalid,'malformed document also caches result/diagnostics');
 detach();assert.equal(read().diagnostics.length,0);
 const boot=async(g:typeof game)=>{const ctx=createGameContext({definition:g.game,content:g.content,models:{entity:kind=>(g.entityModels as any)[kind],object:kind=>(g.objectModels as any)[kind]},player:{userId:`${name}-prepared-authoring`,isNew:true}});g.loop.onInit(ctx);g.loop.onNewPlayer(ctx);await Promise.resolve();if(name==='scrap')await ctx.game.commands.run('character.pick',{characterId:'gunk'});return ctx;};
 const before=await boot(original);const after=await boot(game);
 assert.equal(after.scene.object.get(markerId),null,'normal lifecycle creates no duplicate static actor');
 assert.deepEqual(after.scene.entity.get(`${name}-prepared-authoring`),before.scene.entity.get(`${name}-prepared-authoring`),'normal actor placement/stats/heading preserved');
 const objectIds=(ctx:typeof after)=>ctx.scene.object.all().map(o=>o.instanceId).sort();assert.deepEqual(objectIds(after),objectIds(before),'all original placement ids preserved');
 for(const id of objectIds(before))assert.deepEqual(after.scene.object.get(id),before.scene.object.get(id),'original object placement including0.5 offset preserved');
 records.push({game:name,modelKeys:Object.keys(models).length,changedAnimationKinds:actorKinds,allOtherModelFieldsPreserved:true,allOtherAnimationsPreserved:true,canonicalMarkerId:markerId,catalogId:assetId,previewClipCount:asset.clips?.length,normalBootPlayerUnchanged:true,noDuplicateStaticActor:true,originalPlacementCount:objectIds(before).length,allOriginalObjectsIncludingElevationPreserved:true,liveAdjustmentThroughPublicModelResolver:true,diagnostic,diagnosticsAccessible:'exported readPlayerAnimation() result; no existing game-local warning sink',preparedDocumentSha256:sha(sourceText),fullSaveReload:name==='scrap',fullSaveLimitation:name==='lantern'?'original unsupported dawn unchanged; saved/loaded character slice only':undefined});
}
writeFileSync(new URL('./prepared-adapter-proof.json',import.meta.url),JSON.stringify({label:'Prepared isolated game adapters verified against unreleased public package; no shipped adoption/native appearance',cohort:manifest.commit,tree:manifest.tree,records},null,2)+'\n');
console.log(JSON.stringify(records));
