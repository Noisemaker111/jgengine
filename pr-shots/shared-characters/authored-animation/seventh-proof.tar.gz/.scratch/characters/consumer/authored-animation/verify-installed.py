from pathlib import Path
import hashlib,json,tarfile
base=Path(__file__).resolve().parent
manifest=json.loads((base/'candidate-package-manifest.json').read_text())
rows=[]
for package in manifest['packages']:
    tarball=Path(package['path'])
    assert hashlib.sha256(tarball.read_bytes()).hexdigest()==package['sha256'],package['name']
    installed=base/'node_modules'/package['name']
    if not installed.exists():
        continue
    count=0
    with tarfile.open(tarball,'r:gz') as archive:
        for member in archive.getmembers():
            if not member.isfile():
                continue
            rel=Path(member.name).relative_to('package')
            actual=(installed/rel).read_bytes()
            expected=archive.extractfile(member).read()
            assert actual==expected,(package['name'],str(rel))
            count+=1
    rows.append({'name':package['name'],'version':package['version'],'tarballSha256':package['sha256'],'installedFilesByteVerified':count})
report={'label':'unreleased public package fixture; no release adoption','commit':manifest['commit'],'tree':manifest['tree'],'allManifestTarballsHashed':len(manifest['packages']),'installedPackages':rows,'uninstalledPackages':[p['name'] for p in manifest['packages'] if not (base/'node_modules'/p['name']).exists()]}
(base/'installed-package-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
