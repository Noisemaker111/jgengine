import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createEditorSession} from '@jgengine/core/editor/commands';
import {exportEditorDocumentJson,importEditorDocumentJson,type EditorDocument} from '@jgengine/core/editor/document';
const hash=(s:string)=>createHash('sha256').update(s).digest('hex');
const result=[];
for(const [game,id,catalog,graph] of [
 ['scrap-signal','player_spawn','kaykit-adventurers/Rogue_Hooded','scrap'],
 ['lantern-reach','spawn:player','lantern:knight','lantern'],
]){
 const file=new URL(`./games/${game}/src/editor.scene.json`,import.meta.url);
 const originalText=readFileSync(file,'utf8');const original=JSON.parse(originalText) as EditorDocument;
 const animation=JSON.parse(readFileSync(new URL(`../../authored-animation/${graph}-animation.json`,import.meta.url),'utf8'));
 const marker=original.markers.find(m=>m.id===id)!;assert.ok(marker);
 const session=createEditorSession(original);
 session.dispatch({type:'setMarker',id,patch:{meta:{...marker.meta,catalogId:catalog,animation}}});
 const edited=session.getState().document;const originalCopy=structuredClone(edited);
 originalCopy.markers.find(m=>m.id===id)!.meta=marker.meta;assert.deepEqual(originalCopy,original);
 const text=exportEditorDocumentJson(edited);let fullSaveReload=true;let limitation:string|undefined;
 try{assert.deepEqual(importEditorDocumentJson(text).markers.find(m=>m.id===id)?.meta,edited.markers.find(m=>m.id===id)?.meta)}
 catch(error){fullSaveReload=false;limitation=String(error);assert.equal(game,'lantern-reach');assert.match(limitation,/environment.preset/)}
 writeFileSync(file,text+'\n');
 result.push({game,markerId:id,catalogId:catalog,originalSha256:hash(originalText),preparedSha256:hash(text+'\n'),onlyMarkerMetaChanged:true,normalSetMarkerCommand:true,normalPublicExport:true,fullSaveReload,limitation});
}
writeFileSync(new URL('./prepared-document-edits.json',import.meta.url),JSON.stringify({label:'Prepared candidate character metadata authored via normal public scene command/export; original game repos untouched; full Lantern reload remains blocked by original dawn.',result},null,2)+'\n');
console.log(JSON.stringify(result));
