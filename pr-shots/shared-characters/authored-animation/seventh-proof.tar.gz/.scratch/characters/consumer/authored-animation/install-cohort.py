from pathlib import Path
import json,hashlib,sys

base=Path(__file__).resolve().parent
assert base.name=='authored-animation',base
assert not (base/'node_modules').is_symlink(),'unlink baseline node_modules symlink before independent install'
manifest=Path(sys.argv[1]).resolve()
data=json.loads(manifest.read_text())
for package in data['packages']:
    assert hashlib.sha256(Path(package['path']).read_bytes()).hexdigest()==package['sha256'],package['name']
path=base/'package.json'
package=json.loads(path.read_text())
for entry in data['packages']:
    spec='file:'+entry['path']
    if entry['name'] in package['dependencies']:
        package['dependencies'][entry['name']]=spec
    if entry['name']!='jgengine':
        package['overrides'][entry['name']]=spec
path.write_text(json.dumps(package,indent=2)+'\n')
(base/'candidate-package-manifest.json').write_text(manifest.read_text())
print(json.dumps({'cohort':data['commit'],'tree':data['tree'],'tarballHashesVerified':len(data['packages']),'scope':'isolated authored-animation fixture only; no other fixture or repository lock changes'}))
