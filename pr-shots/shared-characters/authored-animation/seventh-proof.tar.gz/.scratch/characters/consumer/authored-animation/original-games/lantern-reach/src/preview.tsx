import type { CSSProperties } from "react";
import type { GamePreviewProps } from "@jgengine/react/preview";

const HUB_TINT = "#79a35c";

const MOBS = [
  { left: "18%", top: "70%" },
  { left: "78%", top: "66%" },
  { left: "70%", top: "30%" },
];

function barStyle(): CSSProperties {
  return {
    width: "9cqw",
    height: "0.9cqw",
    borderRadius: "0.2cqw",
    border: "1px solid rgba(0,0,0,0.5)",
    background: "rgba(0,0,0,0.5)",
    overflow: "hidden",
  };
}

export default function LanternReachPreview({ className }: GamePreviewProps) {
  return (
    <div
      className={className}
      style={{
        containerType: "size",
        position: "relative",
        height: "100%",
        width: "100%",
        overflow: "hidden",
        background: `radial-gradient(120% 100% at 50% 30%, ${HUB_TINT} 0%, #4d6b3a 55%, #2c3d20 100%)`,
        color: "#fff",
        fontFamily: "ui-sans-serif, system-ui, sans-serif",
        userSelect: "none",
      }}
    >
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "58%",
          width: "34cqw",
          height: "34cqw",
          transform: "translate(-50%, -50%)",
          borderRadius: "50%",
          border: "0.3cqw solid rgba(217,119,6,0.55)",
          background: "radial-gradient(circle, rgba(0,0,0,0.12), transparent 70%)",
        }}
      />

      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "58%",
          transform: "translate(-50%, -50%)",
          width: "5cqw",
          height: "5cqw",
          borderRadius: "0.6cqw",
          background: "linear-gradient(155deg, #c79c6e, #8a6b48)",
          border: "1px solid rgba(0,0,0,0.45)",
          boxShadow: "0 0.6cqw 1.2cqw rgba(0,0,0,0.4)",
        }}
      />
      <span
        style={{
          position: "absolute",
          left: "50%",
          top: "50%",
          transform: "translate(-50%, -50%)",
          width: "1.6cqw",
          height: "1.6cqw",
          borderRadius: "50%",
          background: "#fef3c7",
          border: "1px solid #451a03",
          boxShadow: "0 0 1cqw rgba(254,243,199,0.8)",
        }}
      />

      {MOBS.map((mob, i) => (
        <span
          key={i}
          style={{
            position: "absolute",
            left: mob.left,
            top: mob.top,
            width: "1cqw",
            height: "1cqw",
            borderRadius: "50%",
            background: "#dc2626",
            boxShadow: "0 0 0.6cqw rgba(220,38,38,0.7)",
          }}
        />
      ))}

      <div
        style={{
          position: "absolute",
          top: "3cqh",
          left: "3cqw",
          display: "flex",
          flexDirection: "column",
          gap: "0.5cqw",
          borderRadius: "0.6cqw",
          border: "1px solid #44403c",
          background: "rgba(28,25,23,0.82)",
          padding: "1cqw 1.4cqw",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "0.6cqw" }}>
          <span
            style={{
              borderRadius: "0.3cqw",
              border: "1px solid rgba(217,119,6,0.6)",
              padding: "0.1cqw 0.6cqw",
              fontSize: "1cqw",
              fontWeight: 800,
              color: "#fef3c7",
            }}
          >
            Lv 1
          </span>
        </div>
        <div style={barStyle()}>
          <div style={{ width: "100%", height: "100%", background: "#dc2626" }} />
        </div>
        <div style={barStyle()}>
          <div style={{ width: "100%", height: "100%", background: "#0ea5e9" }} />
        </div>
      </div>

      <div
        style={{
          position: "absolute",
          bottom: "3cqh",
          left: "50%",
          transform: "translateX(-50%)",
          display: "flex",
          gap: "0.5cqw",
        }}
      >
        {Array.from({ length: 6 }, (_, i) => (
          <div
            key={i}
            style={{
              width: "3.4cqw",
              height: "3.4cqw",
              borderRadius: "0.4cqw",
              background: i === 0 ? "rgba(217,119,6,0.35)" : "rgba(28,25,23,0.75)",
              border: i === 0 ? "1px solid #d97706" : "1px solid #44403c",
              display: "flex",
              alignItems: "flex-end",
              justifyContent: "flex-end",
              padding: "0.2cqw",
            }}
          >
            <span style={{ fontSize: "0.9cqw", fontWeight: 700, color: "rgba(255,255,255,0.6)" }}>{i + 1}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
