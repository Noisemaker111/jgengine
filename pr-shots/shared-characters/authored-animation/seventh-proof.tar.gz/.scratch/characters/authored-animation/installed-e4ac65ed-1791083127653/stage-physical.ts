import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {resolve} from 'node:path';
import {game as scrap} from '/workspace/JGengine/.scratch/characters/consumer/authored-animation/games/scrap-signal/src/game.config';
import {game as lantern} from '/workspace/JGengine/.scratch/characters/consumer/authored-animation/games/lantern-reach/src/game.config';
import {createGameContext} from '@jgengine/core/runtime/gameContext';
import {resolvePlayerMovementTuning,stepPlayerMovement,snapshotPlayerMovement} from '@jgengine/core/movement/playerMovement';
import {readModelAnimationParams} from '@jgengine/shell/render/useModelAnimation';
import {resolveEntityModel} from '@jgengine/shell/render/resolveModel';
import {resolveAnimationConfig} from '@jgengine/core/game/clipRoles';
import {animGraphFromConfig} from '@jgengine/core/anim/locomotionGraph';
import {createAnimGraphRuntime,parseAnimGraph} from '@jgengine/core/anim/animGraph';
import {seededRng} from '@jgengine/core/random/rng';
import {createEmptyEditorDocument,importEditorDocumentJson,exportEditorDocumentJson} from '@jgengine/core/editor/document';
import {createEditorSession} from '@jgengine/core/editor/commands';
import {createMovementSchema,createAuthoredMovementReader,bindAuthoredMovement} from '@jgengine/core/editor/movementCatalog';
import {createAuthoredAnimationReader} from '@jgengine/core/world/authoredAnimation';
import {createEditorHost} from '@jgengine/editor/session';

const sha=(value:string|Buffer)=>createHash('sha256').update(value).digest('hex');
const profiles=JSON.parse(readFileSync(resolve(import.meta.dir,'asset-profiles.json'),'utf8'));
const actualDurations=JSON.parse(readFileSync(resolve(import.meta.dir,'actual-clip-durations.json'),'utf8'));
const manifest=JSON.parse(readFileSync(new URL('./candidate-package-manifest.json',import.meta.url),'utf8'));
const req=createRequire(resolve(import.meta.dir,'package.json'));
const modules=Object.fromEntries(['@jgengine/core/movement/playerMovement','@jgengine/core/anim/animGraph','@jgengine/core/world/authoredAnimation','@jgengine/shell/render/useModelAnimation','@jgengine/editor/session'].map(name=>[name,req.resolve(name)]));
assert.ok(Object.values(modules).every(path=>path.includes('/node_modules/')&&!path.includes('/JGengine/packages/')));
const report:any={cohort:manifest.commit,tree:manifest.tree,stage:'integrated installed authored animation reader',modulePaths:modules,moduleHashes:Object.fromEntries(Object.entries(modules).map(([name,path])=>[name,sha(readFileSync(path))])),originalGameSource:'45a50523cae2021c412aa83ce50589d806dd96d9',normalBootAndPlayerInput:true,noPositionSceneOrGameSourceWrites:true,limitation:'Numerical physical movement and graph output only; no native appearance, control feel, published adoption or hardware performance claim.',games:{}};
report.executionSourceSha256=sha(readFileSync(new URL(import.meta.url)));
report.correction='v2 selects an existing attacker using SceneEntity.id; original target-only hit proof had an undefined attacker.';

for(const [name,game] of Object.entries({scrap,lantern})){
 const profile={...profiles[name],durations:actualDurations[name]};assert.equal(sha(readFileSync(profile.path)),profile.sha256);
 const setting=JSON.parse(readFileSync(resolve(import.meta.dir,`${name}-animation.json`),'utf8'));
 const markerId=name==='scrap'?'player_spawn':'spawn:player';
 const originalText=readFileSync(resolve('/workspace/JGengine/.scratch/characters/consumer/authored-animation',`games/${name==='scrap'?'scrap-signal':'lantern-reach'}/src/editor.scene.json`),'utf8');
 const original=name==='scrap'?importEditorDocumentJson(originalText):JSON.parse(originalText);
 const doc=name==='scrap'?structuredClone(original):createEmptyEditorDocument();
 if(name==='lantern')doc.markers=[structuredClone(original.markers.find(m=>m.id===markerId)!)];
 const host=createEditorHost({gameId:`${name}-authored-animation-proof`,layers:doc,publishGlobal:false});
 const patch=host.api.handle({method:'set_meta',id:markerId,patch:{animation:setting}});assert.equal(patch.ok,true);
 const exported=host.api.handle({method:'export_document'});assert.equal(exported.ok,true);
 const saved=(exported.result as any).json as string;writeFileSync(new URL(`./${name}-animation-saved-document.json`,import.meta.url),saved);
 const reopened=importEditorDocumentJson(saved);const savedRead=createAuthoredAnimationReader(()=>reopened,markerId);const authored=savedRead().animation!;assert.deepEqual(savedRead().diagnostics,[]);
 assert.equal(typeof authored,'object');const savedGraph=parseAnimGraph((authored as any).graph)!;assert.ok(savedGraph);assert.deepEqual(savedGraph,setting.graph);
 const restored=structuredClone(reopened);restored.markers.find(m=>m.id===markerId)!.meta=doc.markers.find(m=>m.id===markerId)!.meta;
 assert.deepEqual(restored,doc,'only animation metadata changes; authored spawn and all world content remain intact');
 host.dispose();
 const uid=`${name}-physical-authored-animation`;
 const make=async()=>{const ctx=createGameContext({definition:game.game,content:game.content,models:{entity:kind=>(game.entityModels as any)[kind],object:kind=>(game.objectModels as any)[kind]},player:{userId:uid,isNew:true}});game.loop.onInit(ctx);game.loop.onNewPlayer(ctx);await Promise.resolve();if(name==='scrap')await ctx.game.commands.run('character.pick',{characterId:'gunk'});return ctx;};
 const ctx=await make();const actor=ctx.scene.entity.get(uid)!;const model=(game.entityModels as any)[actor.name];
 const liveRead=createAuthoredAnimationReader(()=>reopened,markerId,model.animation);assert.equal(liveRead(),liveRead());const preparedModel=resolveEntityModel({...model,get animation(){return liveRead().animation;}},game.game.assets,actor.name)!;assert.deepEqual(liveRead().diagnostics,[]);
 assert.equal(preparedModel.url,model.url);assert.equal(preparedModel.targetHeight,model.targetHeight);
 const authoredGraph=animGraphFromConfig(resolveAnimationConfig(preparedModel.animation,profile.clips)!)!;
 assert.deepEqual(authoredGraph,savedGraph,'saved character override passes through existing public entity-model and animation resolvers');
 const baselineGraph=animGraphFromConfig(resolveAnimationConfig(model.animation,profile.clips)!)!;
 const seed=JSON.stringify(['model-animation',uid,[...profile.clips].sort()]);
 const runtime=createAnimGraphRuntime(authoredGraph,{rng:seededRng(seed)}),baseline=createAnimGraphRuntime(baselineGraph,{rng:seededRng(seed)});
 const routedEvents:any[]=[];
 const route=(event:string,payload:any)=>{runtime.trigger(event);baseline.trigger(event);routedEvents.push({event,payload});};
 const off=[ctx.game.events.on('entity.animation',e=>{if(e.instanceId===uid)route(e.event,e);}),ctx.game.events.on('combat.hitReaction',e=>{if(e.instanceId===uid)route('hit',e);}),ctx.game.events.on('entity.died',e=>{if(e.instanceId===uid)route('death',e);})];
 const tuning=resolvePlayerMovementTuning({world:game.game.world,physics:game.game.physics,movement:game.movement,collision:game.collision});
 const params:any={};let lastPosition:[number,number,number]|null=null,speed=0,frame=0;
 const tick=(held:string[]=[])=>{
  stepPlayerMovement(ctx,uid,{held,pointer:null},1/120,tuning);
  const entity=ctx.scene.entity.get(uid)!;const pos=[...entity.position] as [number,number,number];
  if(lastPosition!==null)speed+=(Math.hypot(pos[0]-lastPosition[0],pos[2]-lastPosition[2])*120-speed)*.1;lastPosition=pos;
  readModelAnimationParams(ctx,uid,speed,params);
  const out=runtime.advance(1/120,params,profile.durations),before=baseline.advance(1/120,params,profile.durations);
  for(const c of out.clips){assert.ok(profile.clips.includes(c.clip));assert.ok(Number.isFinite(c.time)&&Number.isFinite(c.weight));}
  return{frame:frame++,position:pos,params:structuredClone(params),state:runtime.stateOf('base'),baselineState:baseline.stateOf('base'),selectedClip:runtime.snapshot().layers.base.selectedClip,baselineSelectedClip:baseline.snapshot().layers.base.selectedClip,clips:out.clips,baselineClips:before.clips,motion:snapshotPlayerMovement(ctx,uid)!.motion};
 };
 for(let i=0;i<60;i++)tick();
 const settled=[...ctx.scene.entity.get(uid)!.position];const frames=[];
 for(let i=0;i<180;i++)frames.push(tick(i===0?['jump']:[]));
 const states=[...new Set(frames.map(f=>f.state))];const airborneFrames=frames.filter(f=>f.params.grounded===false);
 if(name==='scrap'&&!states.includes('airborne'))writeFileSync(new URL('./physical-authored-animation-seventh-initial-failure.json',import.meta.url),JSON.stringify({cohort:manifest.commit,kind:actor.name,assetSha256:profile.sha256,jumpStartDuration:profile.durations.Jump_Start,states,frames,limitation:'authored jumpStart exit waits for actual clip duration longer than physical jump; descent stays in jumpStart and Jump_Idle never plays'},null,2)+'\n');
 assert.ok(airborneFrames.length>0);assert.ok(airborneFrames.every(f=>f.baselineClips.every(c=>c.clip==='Idle')));
 if(name==='lantern'){assert.ok(states.includes('airborne'));assert.ok(airborneFrames.some(f=>f.clips.some(c=>c.clip==='Jump_Idle'&&c.weight>.99)));}
 else for(const state of ['jumpStart','airborne','landing','locomotion'])assert.ok(states.includes(state),`physical jump visits ${state}`);
 assert.equal(frames.at(-1)!.motion.grounded,true);assert.equal(frames.at(-1)!.state,'locomotion');
 const extra:any={};
 if(name==='scrap'){
  let firstLanding:any=null;for(let i=0;i<180;i++){const f=tick(i===0?['jump']:[]);if(f.state==='landing'&&f.params.grounded===true){firstLanding=f;break;}}
  assert.ok(firstLanding);const rapid=tick(['jump']);assert.equal(rapid.params.grounded,false);assert.equal(rapid.state,'jumpStart');
  for(let i=0;i<4;i++)tick();ctx.game.playEntityAnimation(uid,'attack');const attack=tick();assert.equal(attack.state,'attack');
  assert.equal(attack.selectedClip,attack.baselineSelectedClip);
  assert.deepEqual(authoredGraph.layers[0].states.attack,baselineGraph.layers[0].states.attack,'attack variants retain actual auto mapping');
  const from=ctx.scene.entity.list().find(e=>e.id!==uid)!.id;assert.ok(ctx.scene.entity.get(from),'hit-reaction attacker is a real normally spawned actor');
  assert.ok(ctx.scene.entity.hitReaction({from,to:uid,config:{hitstopMs:0,knockback:0}}));const hit=tick();assert.equal(hit.state,'hit');
  assert.equal(hit.selectedClip,hit.baselineSelectedClip);
  assert.deepEqual(authoredGraph.layers[0].states.hit,baselineGraph.layers[0].states.hit);
  ctx.game.playEntityAnimation(uid,'attack');ctx.game.playEntityAnimation(uid,'death');const death=tick();assert.equal(death.state,'death');
  assert.equal(death.selectedClip,death.baselineSelectedClip);
  assert.deepEqual(authoredGraph.layers[0].states.death,baselineGraph.layers[0].states.death);
  ctx.game.playEntityAnimation(uid,'hit');ctx.game.playEntityAnimation(uid,'attack');const terminal=[];for(let i=0;i<240;i++)terminal.push(tick(i===0?['jump']:[]));
  assert.ok(terminal.every(f=>f.state==='death'));assert.ok(terminal.at(-1)!.clips.every(c=>Math.abs(c.time-profile.durations[c.clip])<1e-6));
  extra.rapidLandingInterruption={firstLanding,rapid};extra.combatInterruption={attack,hit,death,terminalFinal:terminal.at(-1),routedEvents,deathContract:'explicit public entity.animation death trigger; actual Scrap player health floor1 is retained, no player-kill claim'};
  extra.combatInterruption.hitReactionAttacker={id:from,kind:ctx.scene.entity.get(from)!.name,position:[...ctx.scene.entity.get(from)!.position]};
  const bufferSession=createEditorSession(reopened);bufferSession.dispatch({type:'addCatalog',id:'player-motion',schema:createMovementSchema({jumpBufferMs:100})});bufferSession.dispatch({type:'addCatalogEntry',catalogId:'player-motion',entry:{id:actor.name,meta:{jumpBufferMs:100}}});
  const bufferText=exportEditorDocumentJson(bufferSession.getState().document);writeFileSync(new URL('./scrap-buffered-animation-saved-document.json',import.meta.url),bufferText);
  const bufferDoc=importEditorDocumentJson(bufferText),bufferRead=createAuthoredMovementReader(()=>bufferDoc,'player-motion',actor.name),binding=bindAuthoredMovement(bufferRead,{movement:game.movement,physics:game.game.physics});
  assert.equal(binding.movement.beforeCommit,game.movement?.beforeCommit);
  const bufferControlRecognized=binding.movement.feel?.jumpBufferMs===100;
  assert.equal(bufferControlRecognized,true,'final integrated public reader must expose authored buffer100; runtime fallback forbidden in final proof');const bufferedMovement=binding.movement;
  extra.bufferConfigurationBoundary={savedControl:100,readerRecognizesControl:bufferControlRecognized,mode:bufferControlRecognized?'public authored movement reader':'explicit existing runtime feel setting for graph-only proof; sixth cohort lacks fifth authored-control reader extension'};
  const buffered=[];
  for(const skipContactRender of [false,true]){
   const other=await make(),graph=createAnimGraphRuntime(authoredGraph),motionTuning=resolvePlayerMovementTuning({world:game.game.world,physics:binding.physics,movement:bufferedMovement,collision:game.collision});
   const step=(held:string[])=>stepPlayerMovement(other,uid,{held,pointer:null},1/120,motionTuning);
   for(let i=0;i<60;i++){step([]);graph.advance(1/120,readModelAnimationParams(other,uid,0,{}),profile.durations);}
   const floor=other.scene.entity.get(uid)!.position[1];let queued=false,firstAir=false,groundAfterQueue=false,secondLaunch=false,skipped=false,elapsed=0;const samples=[];
   for(let i=0;i<180;i++){
    const previous=snapshotPlayerMovement(other,uid)!.motion!;const feet=other.scene.entity.get(uid)!.position[1];
    const press=i===0||(!queued&&!previous.grounded&&previous.verticalVelocity<0&&feet-floor<.1);
    if(i>0&&press)queued=true;step(press?['jump']:[]);elapsed+=1/120;
    const p=readModelAnimationParams(other,uid,0,{});firstAir ||= p.grounded===false;
    const contact=queued&&firstAir&&p.grounded===true;if(contact)groundAfterQueue=true;
    const shouldSkip=skipContactRender&&contact&&!skipped;if(shouldSkip)skipped=true;else{graph.advance(elapsed,p,profile.durations);elapsed=0;}
    const sample={frame:i,position:[...other.scene.entity.get(uid)!.position],params:structuredClone(p),press,renderSkipped:shouldSkip,state:graph.stateOf('base')};samples.push(sample);
    if(groundAfterQueue&&p.grounded===false&&Number(p.verticalSpeed)>0){secondLaunch=true;break;}
   }
   assert.ok(queued&&groundAfterQueue&&secondLaunch,'authored buffer launches on actual floor contact');
   const result={skipContactRender,savedDocumentSha256:sha(bufferText),jumpBufferMs:100,samples,finalState:graph.stateOf('base')};buffered.push(result);
   if(graph.stateOf('base')!=='jumpStart')writeFileSync(new URL('./physical-buffered-animation-initial-failure.json',import.meta.url),JSON.stringify({cohort:manifest.commit,assetSha256:profile.sha256,...result},null,2)+'\n');
   assert.equal(graph.stateOf('base'),'jumpStart','buffered launch starts the imported jump clip even when the render misses one grounded physics frame');
  }
  extra.bufferedLanding=buffered;
  const slow=await make();let liveGravity=game.game.physics!.gravity;
  const slowPhysics={...game.game.physics,get gravity(){return liveGravity;}};
  const slowTuning=resolvePlayerMovementTuning({world:game.game.world,physics:slowPhysics,movement:game.movement,collision:game.collision});
  const slowGraph=createAnimGraphRuntime(authoredGraph);const slowStep=(held:string[])=>stepPlayerMovement(slow,uid,{held,pointer:null},1/120,slowTuning);
  for(let i=0;i<60;i++){slowStep([]);slowGraph.advance(1/120,readModelAnimationParams(slow,uid,0,{}),profile.durations);}
  liveGravity=-8.4;const slowFrames=[];
  for(let i=0;i<360;i++){slowStep(i===0?['jump']:[]);const p=readModelAnimationParams(slow,uid,0,{});const out=slowGraph.advance(1/120,p,profile.durations);slowFrames.push({frame:i,params:structuredClone(p),state:slowGraph.stateOf('base'),clips:out.clips,position:[...slow.scene.entity.get(uid)!.position]});}
  const risingAfterClip=slowFrames.filter(f=>f.frame/120>profile.durations.Jump_Start&&Number(f.params.verticalSpeed)>0&&f.params.grounded===false);
  assert.ok(risingAfterClip.length>0);assert.ok(risingAfterClip.every(f=>f.state==='jumpStart'));
  assert.ok(risingAfterClip.some(f=>f.clips.some(c=>c.clip==='Jump_Start'&&Math.abs(c.time-profile.durations.Jump_Start)<1e-6)));
  const slowTransitions=slowFrames.filter((f,i)=>i===0||f.state!==slowFrames[i-1].state).map(f=>f.state);
  assert.deepEqual(slowTransitions,['jumpStart','airborne','landing','locomotion']);
  extra.slowerGravityControl={label:'explicit live runtime gravity retuning regression; actual original normal-game profile remains unchanged',normalGravity:game.game.physics!.gravity,retunedGravity:liveGravity,startClipDuration:profile.durations.Jump_Start,risingFramesAfterClipCompletion:risingAfterClip.length,transitions:slowTransitions,frames:slowFrames};
 }
 off.forEach(fn=>fn());
 report.games[name]={kind:actor.name,perspective:game.camera?.perspective,localRigVisibility:name==='scrap'?'hidden by original first-person host policy':'existing third-person player composition',documentScope:name==='scrap'?'full original438-marker document':'labelled canonical-spawn slice; original full Lantern Dawn save remains unrelatedblocked',markerCount:reopened.markers.length,markerId,savedDocumentSha256:sha(saved),assetSha256:profile.sha256,clipCount:profile.clips.length,clipDurations:profile.durations,animation:authored,settledPosition:settled,peakHeight:Math.max(...frames.map(f=>f.position[1]))-settled[1],states,frames,...extra};
}
writeFileSync(new URL('./physical-authored-animation-seventh.json',import.meta.url),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({cohort:report.cohort,games:Object.fromEntries(Object.entries(report.games).map(([name,g]:[string,any])=>[name,{kind:g.kind,markerCount:g.markerCount,states:g.states,peakHeight:g.peakHeight,combat:g.combatInterruption!==undefined}]))}));
